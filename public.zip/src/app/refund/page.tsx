export default function RefundPolicy() {
  return (
    <main className="container" style={{ paddingTop: '140px', paddingBottom: '4rem', maxWidth: '800px' }}>
      <h1 className="text-gradient" style={{ fontSize: 'clamp(2rem, 5vw, 2.5rem)', marginBottom: '2rem' }}>Refund Policy</h1>
      
      <div className="glass-panel" style={{ padding: 'clamp(1.2rem, 4vw, 2rem)', lineHeight: '1.6', color: 'var(--foreground)' }}>
        <p>We have a 7-day return policy, which means you have 7 days after receiving your item to request a return. To be eligible for a return, your item must be in the same condition that you received it, unworn or unused, with tags, and in its original packaging. You’ll also need the receipt or proof of purchase. To start a return, you can contact us at <strong>theusualsalem@gmail.com</strong>.</p>
        
        <p>If your return is accepted, we’ll send you instructions on how and where to send your package. Items sent back to us without first requesting a return will not be accepted. You can always contact us for any return question at <strong>theusualsalem@gmail.com</strong>.</p>
        
        <h2 style={{ marginTop: '2rem', marginBottom: '1rem', color: '#1a1a2e' }}>Damages and issues</h2>
        <p>Please inspect your order upon reception and contact us immediately if the item is defective, damaged or if you receive the wrong item, so that we can evaluate the issue and make it right.</p>

        <h2 style={{ marginTop: '2rem', marginBottom: '1rem', color: '#1a1a2e' }}>Exchanges</h2>
        <p>The fastest way to ensure you get what you want is to return the item you have, and once the return is accepted, make a separate purchase for the new item.</p>

        <h2 style={{ marginTop: '2rem', marginBottom: '1rem', color: '#1a1a2e' }}>Returns</h2>
        <p>A return processing fee may be deducted from the refund amount depending on the return circumstances.</p>

        <h2 style={{ marginTop: '2rem', marginBottom: '1rem', color: '#1a1a2e' }}>Refunds</h2>
        <p>We will notify you once we’ve received and inspected your return, and let you know if the refund was approved or not. If approved, you’ll be automatically refunded on your original payment method within 3 business days. Please remember it can take some time for your bank or credit card company to process and post the refund too.</p>
      </div>
    </main>
  );
}
